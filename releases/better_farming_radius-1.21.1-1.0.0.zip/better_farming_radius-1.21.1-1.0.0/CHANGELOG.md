# Better Farming ++ : Configurable Crate Radius — v1.0.0

Addon NeoForge 1.21.1 pour [Better Farming ++](https://modrinth.com/mod/better-farming-plus).

## Fonctionnalités

- Rayon d'action du Farming Crate configurable (`harvest_radius`, défaut 3, plage 0-32) via
  `config/better_farming_radius-common.toml`.
- Collecte fiable des objets récoltés jusqu'en bordure de la zone d'action.
- Écran de configuration en jeu (bouton "config" dans le menu Mods / Better ModList / Neo Mod Menu).

## Installation

1. Placer `better_farming_radius-1.21.1-1.0.0.jar` dans le dossier `mods/`.
2. S'assurer que **Better Farming ++** (`better_farming_plus`) est également installé.
3. Lancer le jeu une fois pour générer `config/better_farming_radius-common.toml`.
4. Modifier `harvest_radius` (via le fichier ou l'écran de config en jeu).

## Prérequis

- Minecraft 1.21.1
- NeoForge 21.1+
- Better Farming ++ (`better_farming_plus`)
